<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تضمين موقع آخر باستخدام PHP</title>
</head>
<body><?php
// مسار الملفات
$messagesFile = 'messages.txt';

// تحقق إذا تم إرسال الرسالة
if (isset($_POST['message']) && isset($_POST['username']) && isset($_POST['code'])) {
    $username = htmlspecialchars($_POST['username']);
    $code = htmlspecialchars($_POST['code']);
    $message = htmlspecialchars($_POST['message']);
    
    // إضافة اسم الكاتب والكود إلى الرسالة
    $fullMessage = $username . " (" . $code . "): " . $message;
    
    // افتح الملف وأضف الرسالة الجديدة
    file_put_contents($messagesFile, $fullMessage . "\n", FILE_APPEND);
}

// اقرأ جميع الرسائل
$messages = file_exists($messagesFile) ? file($messagesFile) : [];
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام رسائل بسيط</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .chat-container {
            width: 100%;
            max-width: 600px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        input[type="text"] {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .messages {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            max-height: 300px;
            overflow-y: auto;
        }
        .message {
            padding: 10px;
            margin-bottom: 10px;
            background-color: #e9ecef;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<div class="chat-container">
    <h2>نظام رسائل</h2>

    <form method="post" id="messageForm">
        <input type="text" name="message" id="messageInput" placeholder="اكتب رسالتك هنا..." required>
        <button type="submit">إرسال</button>
    </form>

    <div class="messages">
        <?php if (count($messages) > 0): ?>
            <?php foreach ($messages as $msg): ?>
                <div class="message"><?php echo $msg; ?></div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>لا توجد رسائل بعد.</p>
        <?php endif; ?>
    </div>
</div>

<script>
// تحقق من إذا كان المستخدم مسجل في localStorage
if (!localStorage.getItem('username') || !localStorage.getItem('code')) {
    let username = prompt('ادخل اسمك:');
    let code = prompt('ادخل كود مميز (حرف أو رقم):');
    
    // حفظ اسم المستخدم والكود في localStorage
    localStorage.setItem('username', username);
    localStorage.setItem('code', code);
}

// عند إرسال الرسالة، أضف بيانات المستخدم من localStorage
document.getElementById('messageForm').addEventListener('submit', function (e) {
    let username = localStorage.getItem('username');
    let code = localStorage.getItem('code');
    
    // إنشاء مدخلات مخفية لإرسال اسم المستخدم والكود مع الرسالة
    let usernameInput = document.createElement('input');
    usernameInput.type = 'hidden';
    usernameInput.name = 'username';
    usernameInput.value = username;

    let codeInput = document.createElement('input');
    codeInput.type = 'hidden';
    codeInput.name = 'code';
    codeInput.value = code;

    // إضافة المدخلات إلى الفورم
    this.appendChild(usernameInput);
    this.appendChild(codeInput);
});
</script>

</body>
</html>